#define PI 3.14

double calc_perimeter(double r);
double calc_area(double r);

